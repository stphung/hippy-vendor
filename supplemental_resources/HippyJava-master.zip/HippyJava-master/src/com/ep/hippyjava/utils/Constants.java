package com.ep.hippyjava.utils;

import com.google.gson.Gson;

public class Constants {
    public static final String XMPP_URL = "chat.hipchat.com";
    public static final String CONF_URL = "conf.hipchat.com";
    public static final int PORT = 5222;
    public static final Gson GSON = new Gson();

}
