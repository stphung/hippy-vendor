package com.ep.hippyjava.test;

import com.ep.hippyjava.HippyJava;

public class Main {
    
    public static void main(String[] args) {
        HippyJava.runBot(new MyTestBot());
    }

}
