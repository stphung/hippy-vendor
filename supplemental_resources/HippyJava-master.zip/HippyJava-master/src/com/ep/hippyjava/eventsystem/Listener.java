package com.ep.hippyjava.eventsystem;

public interface Listener { }

