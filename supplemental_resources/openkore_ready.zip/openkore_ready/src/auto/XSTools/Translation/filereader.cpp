#include "filereader.h"

FileReader::~FileReader ()
{
	// Do nothing. This is to work around C++'s suckiness.
}
