#ifndef _TIGER_H_
#define _TIGER_H_

#include "../typedefs.h"

CEXTERN void tiger(const dword *str, dword length, dword *res);

#endif
